(function() {
	var button = document.getElementsByTagName('button');
	button[1].onclick=function(){
  	window.location.href="/GLA/Vue/html/AccueilCon.php";
  }
 })();