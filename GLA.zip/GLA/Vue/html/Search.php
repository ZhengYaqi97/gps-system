<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <link href="../css/Search.css" rel="stylesheet" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Search</title>
</head>
<body>
	<?php
	session_start();
	$name="";
	if(!isset($_SESSION['user'])){
		$name="visitor";
		
	}
	else{
		$user = $_SESSION['user'];
		$name = $user;
	}
	
	$url = '../../Controleur/trajet/'.$name.'trajet.json';

	$json_string = file_get_contents($url);
	
	$data = json_decode($json_string, true);
	$count_json = count($data);
	
	?>

<div class="bienvenue" id="bienvenue">Choose your way</div>

<div class="mainpage" id="mainpage"> 
	<form action="/GLA/Controleur/php/Search.php" method="POST">
	<p>These are the ways for you: </p>

	
	<?php 
	if ($data[0]==0){
		echo "Sorry, there is no way.";
		echo "<p></p><button class='sb' type='submit' style='visibility:hidden'>Select</button>";
		//echo "<script>parent.location.href='/GLA/Vue/html/AccueilCon.php';</script>";
	}
	//else if($data[0]==1){
	else if($count_json==2){
	echo "<input type='radio' name='way' value='1'>Way</input>"; $i=1;echo $i.":";
	$count_obj=count($data[0]);
		
	$distance=$data[0][$count_obj-1]['distance'];
	$temps=$data[0][$count_obj-1]['temps'];
	
	$temps=number_format($temps,1);
	echo "Distance : ".$distance." km, Time : ".$temps." h"."<br>";

	echo "<input type='radio' name='way' value='2'>Way</input>"; $i2=2;echo $i2.":";
	$count_obj2=count($data[1]);
		
	$distance2=$data[1][$count_obj2-1]['distance'];
	$temps2=$data[1][$count_obj2-1]['temps'];
	
	$temps2=number_format($temps2,1);
	echo "Distance : ".$distance2." km, Time : ".$temps2." h";

	echo "<br></br><p></p><button class='sb' type='submit'>Select</button>";

	}
	else {

		echo "<input type='radio' name='way' value='1'>Way</input>".":"; 
		$count_obj=count($data);

		$distance=$data[$count_obj-1]['distance'];

		$temps=$data[$count_obj-1]['temps'];
		
		$temps=number_format($temps,1);
		echo "Distance : ".$distance." km, Time : ".$temps." h";
		echo "<br></br><p></p><button class='sb' type='submit'>Select</button>";
	}
	?>
	</form>


	<div class="sign" id="sign">
	<button class="sb2">Back</button>
	</div>
</div>
</body>
<script src='../../Controleur/js/Search.js'></script>
<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
</html>
